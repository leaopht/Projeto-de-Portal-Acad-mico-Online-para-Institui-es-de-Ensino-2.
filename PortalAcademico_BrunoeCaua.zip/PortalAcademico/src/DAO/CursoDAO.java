package DAO;

import model.Curso;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class CursoDAO {

    public void salvar(Curso curso) {
        String sql = "INSERT INTO curso (nome, descricao, carga_horaria, nivel) VALUES (?,?,?,?)";
        Connection conn = Conexao.conectar();

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, curso.getnome());
            stmt.setString(2, curso.getdescricao());
            stmt.setInt(3, curso.getcargaHoraria());
            stmt.setString(4, curso.getnivel());
            stmt.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
