package DAO;

import model.Disciplina;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class DisciplinaDAO {

    public void salvar(Disciplina d) {
        String sql = "INSERT INTO disciplina (nome, descricao, carga_horaria, curso_id) VALUES (?,?,?,?)";
        Connection conn = Conexao.conectar();

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, d.getnome());
            stmt.setString(2, d.getdescricao());
            stmt.setInt(3, d.getcargaHoraria());
            stmt.setInt(4, d.getcursoId());
            stmt.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
