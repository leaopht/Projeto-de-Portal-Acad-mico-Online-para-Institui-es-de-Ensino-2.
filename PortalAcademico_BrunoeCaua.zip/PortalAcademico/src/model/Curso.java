package model;

import javafx.beans.property.SimpleStringProperty;

public class Curso {

    private SimpleStringProperty nome;
    private SimpleStringProperty descricao;
    private SimpleStringProperty nivel;

    public Curso(String nome, String descricao, String nivel) {
        this.nome = new SimpleStringProperty(nome);
        this.descricao = new SimpleStringProperty(descricao);
        this.nivel = new SimpleStringProperty(nivel);
    }

    public String getNome() {
        return nome.get();
    }

    public void setNome(String nome) {
        this.nome.set(nome);
    }

    public String getDescricao() {
        return descricao.get();
    }

    public void setDescricao(String descricao) {
        this.descricao.set(descricao);
    }

    public String getNivel() {
        return nivel.get();
    }

    public void setNivel(String nivel) {
        this.nivel.set(nivel);
    }
}
