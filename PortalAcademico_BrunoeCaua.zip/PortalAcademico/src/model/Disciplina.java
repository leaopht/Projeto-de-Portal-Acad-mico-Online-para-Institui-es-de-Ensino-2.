package model;

import javafx.beans.property.SimpleStringProperty;

public class Disciplina {

    private SimpleStringProperty nome;
    private SimpleStringProperty cargaHoraria;
    private SimpleStringProperty professor;

    public Disciplina(String nome, String cargaHoraria, String professor) {
        this.nome = new SimpleStringProperty(nome);
        this.cargaHoraria = new SimpleStringProperty(cargaHoraria);
        this.professor = new SimpleStringProperty(professor);
    }

    public String getNome() {
        return nome.get();
    }

    public void setNome(String nome) {
        this.nome.set(nome);
    }

    public String getCargaHoraria() {
        return cargaHoraria.get();
    }

    public void setCargaHoraria(String cargaHoraria) {
        this.cargaHoraria.set(cargaHoraria);
    }

    public String getProfessor() {
        return professor.get();
    }

    public void setProfessor(String professor) {
        this.professor.set(professor);
    }
}
 