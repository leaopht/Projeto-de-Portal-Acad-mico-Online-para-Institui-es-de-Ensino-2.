package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import model.Curso;
import model.Disciplina;

public class Admincontroller {

    // ===== CURSOS =====
    @FXML private TextField txtNome;
    @FXML private TextField txtDescricao;
    @FXML private TextField txtNivel;

    @FXML private TableView<Curso> tabelaCursos;
    @FXML private TableColumn<Curso, String> colNome;
    @FXML private TableColumn<Curso, String> colDescricao;
    @FXML private TableColumn<Curso, String> colNivel;

    private ObservableList<Curso> listaCursos = FXCollections.observableArrayList();

    // ===== DISCIPLINAS =====
    @FXML private TextField txtNomeDisc;
    @FXML private TextField txtCargaDisc;
    @FXML private TextField txtProfessorDisc;

    @FXML private TableView<Disciplina> tabelaDisciplinas;
    @FXML private TableColumn<Disciplina, String> colNomeDisc;
    @FXML private TableColumn<Disciplina, String> colCargaDisc;
    @FXML private TableColumn<Disciplina, String> colProfessorDisc;

    private ObservableList<Disciplina> listaDisciplinas = FXCollections.observableArrayList();

    // ===== INITIALIZE =====
    @FXML
    public void initialize() {

        // --- CURSOS ---
        colNome.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(data.getValue().getNome()));
        colDescricao.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(data.getValue().getDescricao()));
        colNivel.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(data.getValue().getNivel()));

        tabelaCursos.setItems(listaCursos);

        tabelaCursos.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldCurso, newCurso) -> {
                    if (newCurso != null) {
                        txtNome.setText(newCurso.getNome());
                        txtDescricao.setText(newCurso.getDescricao());
                        txtNivel.setText(newCurso.getNivel());
                    }
                }
        );

        // --- DISCIPLINAS ---
        colNomeDisc.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(data.getValue().getNome()));
        colCargaDisc.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(data.getValue().getCargaHoraria()));
        colProfessorDisc.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(data.getValue().getProfessor()));

        tabelaDisciplinas.setItems(listaDisciplinas);

        tabelaDisciplinas.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldDisc, newDisc) -> {
                    if (newDisc != null) {
                        txtNomeDisc.setText(newDisc.getNome());
                        txtCargaDisc.setText(newDisc.getCargaHoraria());
                        txtProfessorDisc.setText(newDisc.getProfessor());
                    }
                }
        );
    }

    // ===== CURSOS MÉTODOS =====
    @FXML
    public void adicionarCurso() {
        if (txtNome.getText().isEmpty()) {
            alert("Preencha o nome do curso.");
            return;
        }

        listaCursos.add(new Curso(
                txtNome.getText(),
                txtDescricao.getText(),
                txtNivel.getText()
        ));

        limparCamposCurso();
    }

    @FXML
    public void editarCurso() {
        Curso c = tabelaCursos.getSelectionModel().getSelectedItem();
        if (c == null) {
            alert("Selecione um curso para editar.");
            return;
        }

        c.setNome(txtNome.getText());
        c.setDescricao(txtDescricao.getText());
        c.setNivel(txtNivel.getText());

        tabelaCursos.refresh();
        limparCamposCurso();
    }

    @FXML
    public void excluirCurso() {
        Curso c = tabelaCursos.getSelectionModel().getSelectedItem();
        if (c == null) {
            alert("Selecione um curso para excluir.");
            return;
        }

        listaCursos.remove(c);
        limparCamposCurso();
    }

    // ===== DISCIPLINAS MÉTODOS =====
    @FXML
    public void adicionarDisciplina() {
        if (txtNomeDisc.getText().isEmpty()) {
            alert("Preencha o nome da disciplina.");
            return;
        }

        listaDisciplinas.add(new Disciplina(
                txtNomeDisc.getText(),
                txtCargaDisc.getText(),
                txtProfessorDisc.getText()
        ));

        limparCamposDisciplina();
    }

    @FXML
    public void editarDisciplina() {
        Disciplina d = tabelaDisciplinas.getSelectionModel().getSelectedItem();
        if (d == null) {
            alert("Selecione uma disciplina para editar.");
            return;
        }

        d.setNome(txtNomeDisc.getText());
        d.setCargaHoraria(txtCargaDisc.getText());
        d.setProfessor(txtProfessorDisc.getText());

        tabelaDisciplinas.refresh();
        limparCamposDisciplina();
    }

    @FXML
    public void excluirDisciplina() {
        Disciplina d = tabelaDisciplinas.getSelectionModel().getSelectedItem();
        if (d == null) {
            alert("Selecione uma disciplina para excluir.");
            return;
        }

        listaDisciplinas.remove(d);
        limparCamposDisciplina();
    }

    // ===== LIMPAR CAMPOS =====
    private void limparCamposCurso() {
        txtNome.clear();
        txtDescricao.clear();
        txtNivel.clear();
    }

    private void limparCamposDisciplina() {
        txtNomeDisc.clear();
        txtCargaDisc.clear();
        txtProfessorDisc.clear();
    }

    // ===== ALERTA =====
    private void alert(String msg) {
        Alert a = new Alert(Alert.AlertType.WARNING);
        a.setHeaderText(null);
        a.setContentText(msg);
        a.show();
    }
}
