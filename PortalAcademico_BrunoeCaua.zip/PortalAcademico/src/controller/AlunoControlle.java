package controller;

import java.net.URL;
import java.util.ResourceBundle;

import DAO.CursoDAO;
import DAO.DisciplinaDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Curso;
import model.Disciplina;

public class AlunoControlle implements Initializable {

    // ===== TABELA DE CURSOS =====
    @FXML
    private TableView<Curso> tabelaCursos;

    @FXML
    private TableColumn<Curso, String> colNomeCurso;

    @FXML
    private TableColumn<Curso, String> colNivelCurso;

    // ===== TABELA DE DISCIPLINAS =====
    @FXML
    private TableView<Disciplina> tabelaDisciplinas;

    @FXML
    private TableColumn<Disciplina, String> colNomeDisc;

    @FXML
    private TableColumn<Disciplina, Integer> colCargaDisc;

    // ===== LISTAS =====
    private ObservableList<Curso> listaCursos;
    private ObservableList<Disciplina> listaDisciplinas;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        // -------- CURSOS --------
        colNomeCurso.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colNivelCurso.setCellValueFactory(new PropertyValueFactory<>("nivel"));

        CursoDAO cursoDAO = new CursoDAO();
        listaCursos = FXCollections.observableArrayList(cursoDAO.listar());
        tabelaCursos.setItems(listaCursos);

        // -------- DISCIPLINAS --------
        colNomeDisc.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colCargaDisc.setCellValueFactory(new PropertyValueFactory<>("cargaHoraria"));

        DisciplinaDAO disciplinaDAO = new DisciplinaDAO();
        listaDisciplinas = FXCollections.observableArrayList(disciplinaDAO.listar());
        tabelaDisciplinas.setItems(listaDisciplinas);
    }
}
