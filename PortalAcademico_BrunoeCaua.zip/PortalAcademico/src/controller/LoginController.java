package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class LoginController {

    public void entrarAdmin(ActionEvent event) {
        trocarTela(event, "/View/admin.fxml", "Área do Administrador");
    }

    public void entrarAluno(ActionEvent event) {
        trocarTela(event, "/View/aluno.fxml", "Área do Aluno");
    }

    private void trocarTela(ActionEvent event, String fxml, String titulo) {
        try {
            Stage stage = (Stage) ((Node) event.getSource())
                    .getScene().getWindow();

            Scene scene = new Scene(
                    FXMLLoader.load(getClass().getResource(fxml))
            );

            stage.setScene(scene);
            stage.setTitle(titulo);
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
